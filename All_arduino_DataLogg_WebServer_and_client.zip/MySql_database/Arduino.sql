-- phpMyAdmin SQL Dump
-- version 4.4.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2016 at 05:38 PM
-- Server version: 5.5.44-MariaDB
-- PHP Version: 5.5.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `Arduino`
--

-- --------------------------------------------------------

--
-- Table structure for table `Sensors_Comments`
--

CREATE TABLE IF NOT EXISTS `Sensors_Comments` (
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SensorID` int(10) unsigned NOT NULL,
  `Comments` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Sensors_Data`
--

CREATE TABLE IF NOT EXISTS `Sensors_Data` (
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SensorID` int(10) unsigned NOT NULL,
  `Value_AVE` float NOT NULL,
  `Value_Min` float DEFAULT NULL,
  `Value_Max` float DEFAULT NULL,
  `Value_STD` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Sensors_Desc`
--

CREATE TABLE IF NOT EXISTS `Sensors_Desc` (
  `SensorID` int(10) unsigned NOT NULL,
  `SensorType` varchar(8) NOT NULL,
  `SensorName` varchar(8) NOT NULL,
  `Location` varchar(30) NOT NULL,
  `Parameter` varchar(12) NOT NULL,
  `Unit` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Sensors_Comments`
--
ALTER TABLE `Sensors_Comments`
  ADD UNIQUE KEY `Timestamp-SensorID` (`Timestamp`,`SensorID`),
  ADD KEY `SensorID` (`SensorID`);

--
-- Indexes for table `Sensors_Data`
--
ALTER TABLE `Sensors_Data`
  ADD UNIQUE KEY `Timestamp` (`Timestamp`,`SensorID`),
  ADD KEY `SensorID` (`SensorID`);

--
-- Indexes for table `Sensors_Desc`
--
ALTER TABLE `Sensors_Desc`
  ADD PRIMARY KEY (`SensorID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Sensors_Comments`
--
ALTER TABLE `Sensors_Comments`
  ADD CONSTRAINT `Sensors_Comments_ibfk_1` FOREIGN KEY (`SensorID`) REFERENCES `Sensors_Desc` (`SensorID`);

--
-- Constraints for table `Sensors_Data`
--
ALTER TABLE `Sensors_Data`
  ADD CONSTRAINT `Sensors_Data_ibfk_1` FOREIGN KEY (`SensorID`) REFERENCES `Sensors_Desc` (`SensorID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
