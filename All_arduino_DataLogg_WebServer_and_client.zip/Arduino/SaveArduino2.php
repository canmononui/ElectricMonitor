<?php 
echo "Client IP: ".$_SERVER['REMOTE_ADDR']."<br /> \n";

print_r($_GET);  echo "<br /> \n";
//print_r($_REQUEST);  echo "<br /> \n";
 
$ExpectedPswd="some_password7295";

//extract current file name only
//$page = $_SERVER['PHP_SELF']; //  "/SLE-GSM Radio/FullSIMTableSort.php"
//$page = pathinfo($page);
//$page = $page['basename'];  // "FullSIMTableSort.php"

//four parameters are sending all the time back and forth - sort, sortdir, pagenum, recperpage
//set default sort
//$sort = (isset($_GET['sort'])) ? mysqli_real_escape_string($mysqli, $_GET['sort']) : 'IndexM'; //"mysql_real_escape_string()" is for safety, connection first!
//echo "Sorted by: <b> ".$sort.' </b>';


//$NameArray = array ("SID1", "DHT_H", "DHT_T", "BMP085_T", "BMP085_P", "Password");
//$NameArray = array ("SID1AVE","SID2AVE","SID3AVE","SID4AVE","SID5AVE","SID6AVE","SID7AVE","SID8AVE","Password");
$ValueArray = array();

$NameArray = array_keys ($_GET);
//$ValueArray = 

include "Include_file.php";   //see some constants and functions in here 

//connection to the database  //connection must be established before "mysql_real_escape_string()" call
$mysqli = mysqli_connect($hostname, $username, $password, $dbname) or die("MySQL Error: ".mysqli_error());


for ($i=0; $i<count($NameArray); $i++) 
  {
  $tmp = $_GET[$NameArray[$i]];
  $ValueArray[$i] = (isset($tmp)) ? mysqli_real_escape_string($mysqli, $tmp) : ""; //"mysql_real_escape_string()" is for safety, connection first!
  }

//parsing is done, $NameValueArr contains all data now

//validation
$ValidationArray = array();
$AllValid = TRUE;
for ($i=0; $i<count($NameArray); $i++) 
  {
  if (strcmp($NameArray[$i], "Password") != 0)
     {
     $sid_array = explode("," , $ValueArray[$i]);
	 //validation of one sensor - to improve
	 $ValidationArray[$i] = is_numeric($sid_array[0]) && is_numeric($sid_array[1]) && is_numeric($sid_array[2]) && is_numeric($sid_array[3]);
	 }
	else 
	 {
	 $ValidationArray[$i]= (strcmp($ValueArray[$i], $ExpectedPswd)==0);
	 }
  $AllValid = ($AllValid and $ValidationArray[$i]);
  }
 
//indication
echo "Current reading:<br>\n\r";
for ($i=0; $i<count($NameArray); $i++) 
  {
  echo " ".$NameArray[$i].": ". $ValueArray[$i]." Validated: ";
  if ($ValidationArray[$i]) {echo "YES<br>\r\n";} else {echo "NO<br>\r\n";}
  }
echo "<br/> All Valid: ";if ($AllValid) {echo "YES<br>\r\n";} else {echo "NO<br>\r\n";} 


//exit;


if ($AllValid)
  {
  
  
  //insertion to the combined table  
for ($i=0; $i<(count($NameArray)-1); $i++) //without last one (pswd)
  {
  
  $sid = substr($NameArray[$i], 3);
  $sid = intval($sid);
  //$sid = strval($sid);
  //echo $sid."<br/>";
  
  $sid_array = explode("," , $ValueArray[$i]);
  $insert_string = "INSERT INTO $tablename (`SensorID`, `Value_AVE`, `Value_Min`, `Value_Max`, `Value_STD`) VALUE ($sid, $sid_array[0], $sid_array[1], $sid_array[2], $sid_array[3])";
  
  echo $insert_string."<br>\r\n";
  
  $result = mysqli_query($mysqli, $insert_string) or die("MySQL Error: ".mysqli_error($mysqli)); 
  //if ($result)
  //  {echo "<br/> one record inserted. <br> \r\n";}
  //  else {echo "<br/> ERROR! Nothing is inserted.<br> \r\n";}
  }
//////////////////////////////////////////
  
    /*
  
  //create string to insert, such as it is long - split by two parts
  $insert_string = "INSERT INTO $tablename (Timestamp, $NameArray[0], $NameArray[1], $NameArray[2], $NameArray[3], $NameArray[4])";
  $insert_string .=" VALUE (now(), $ValueArray[0], $ValueArray[1], $ValueArray[2], $ValueArray[3], $ValueArray[4])";
  //actual insert
  $result = mysqli_query($mysqli, $insert_string) or die("MySQL Error: ".mysqli_error()); 
  if ($result)
    {echo "<br/> one record inserted. <br> \r\n";}
    else {echo "<br/> ERROR! Nothing is inserted.<br> \r\n";}
  //echo $insert_string;
  //get number of records
  $result = mysqli_query($mysqli, "SELECT count(*) FROM ".$tablename) or die("MySQL Error: ".mysqli_error()); 
  $row = mysqli_fetch_row($result); //enumerated array
  $reccount=$row[0];
  echo "Total number of records now: " .$reccount. "<br> \n";
  */
  
  
  //close the connection
  mysqli_close($mysqli);
  }

?> 
