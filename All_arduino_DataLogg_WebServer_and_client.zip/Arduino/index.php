<html> 
<head></head> 
<body> 

<h3>Arduino Sensors READ page.</h3>

<?php 
function GetMySQLData_CreateShow_Graph($ASensorID, $Agraph_color='#000000')
{
global $mysqli, $cond, $tablename, $DescTableName, $graph_width, $graph_height;
$DataArray=array(); //array to build the graph
//get Sensor parameters
$query_string = "SELECT * FROM $DescTableName WHERE (SensorID=$ASensorID)";
$result = mysqli_query($mysqli, $query_string) or die("MySQL Error: ".mysqli_error($mysqli));
$row = mysqli_fetch_array($result); //only one record
$SensorName = $row['SensorName'];
$Parameter = $row['Parameter'];
$Location = $row['Location'];
$Unit = $row['Unit'];
//
$Graphfname="_".$ASensorID."_".$SensorName."_".$Parameter.".png"; //graph filename   
$Graphfname=str_replace("#", "_", $Graphfname); //char "#" is not alowed in HTML <img  src=...> tag, not perfect, some other chars are also not alowed?
//
$query_string = "SELECT `Timestamp`, `Value_AVE` FROM $tablename WHERE (SensorID=$ASensorID AND $cond) ORDER BY Timestamp";
$result = mysqli_query($mysqli, $query_string) or die("MySQL Error: ".mysqli_error($mysqli));
while ($row = mysqli_fetch_array($result))  {$dataArray[$row[0]] = $row[1];}

if (is_array($dataArray))
  {
  //data is returned
  //remove all items where value is NULL
  $dataArray = array_diff($dataArray, array(NULL));
  //split the dataarray to the keys and values arrays
  $valuesArray = array_values($dataArray);
  $keysArray = array_keys($dataArray);
  //generate graph
  CreateGraph($valuesArray, $keysArray, $Graphfname, "SensorName: $SensorName, $Parameter ($Unit) \n Location: $Location", $graph_width, $graph_height, $Agraph_color);	
  echo "<img  src=$Graphfname alt='Graph is here.'/> \n"; //<img src="url" alt="some_text"/> 
  }
  else
  {
  //return no data
  echo "<font color='black'> SensorName: </font> <font color='blue'>$SensorName ($Parameter)</font> in <font color='blue'>$Location</font> returns <font color='red'>no data. </font><br> \n";
  }

}


//extract current file name only
$page = $_SERVER['PHP_SELF']; //  "/SLE-GSM Radio/FullSIMTableSort.php"
$page = pathinfo($page);
$page = $page['basename'];  

include "Include_file.php";   //see some constants and functions in here 
	   

//connection to the database  //connection must be established before "mysql_real_escape_string()" call
$mysqli = mysqli_connect($hostname, $username, $password, $dbname) or die("MySQL Error: ".mysqli_error($mysqli));



//Show Table?
$ShowDataTable = (isset($_GET['ShowDataTable'])) ? trim(mysqli_real_escape_string($mysqli, $_GET['ShowDataTable'])) : 'No'; 



//FromDateTime and ToDateTime
$FromDateTime = (isset($_GET['FromDateTime'])) ? trim(mysqli_real_escape_string($mysqli, $_GET['FromDateTime'])) : '-2 DAYS'; 
$ToDateTime = (isset($_GET['ToDateTime'])) ? trim(mysqli_real_escape_string($mysqli, $_GET['ToDateTime'])) : 'NOW'; 

//get sensors desc for selection checkboxes
$result = mysqli_query($mysqli, "SELECT * FROM Sensors_Desc WHERE SensorID <> 0") or die("MySQL Error: ".mysqli_error($mysqli));

if ($ShowDataTable=='Yes') {$check='checked';} else {$check='';}
echo "<form method='get'> \n";  
echo "Graph from: <input type='text' name='FromDateTime' size=20 value='$FromDateTime' /> \n";
echo "to: <input type='text' name='ToDateTime' size=20 value='$ToDateTime' /> \n";
echo "<input type='checkbox' name='ShowDataTable' $check value='Yes'>Show Data Table <br> \n";

//show selection checkboxes
/*
echo "<input type='checkbox' name='ShowSel' value='Y'> Show Selection checkboxes <br> \n";
while ($row = mysqli_fetch_array($result)) 
    {
	$nm = 'SID'.$row['SensorID'];  //
	$txtdesc = $nm." - ".$row['Location'];
	echo "&nbsp;&nbsp;&nbsp;&nbsp; <input type='checkbox' name='$nm' value='Y'> $txtdesc <br> \n";
    }
*/	
//end of selection checkboxes



echo "<input type='submit' name='submit' value='Refresh Graph' /> <br /> \n";




echo "</form> \n";

//read any format, convert to proper for MySQL format "2013-4-1" 
//if started from "-" - use intervals???  sample: WHERE Test > DATE_SUB(now(), INTERVAL $interval), $interval = '10 MINUTE';
if ($FromDateTime != '') 
  {$FromDateTime = date('Y-m-d H:i:s', strtotime($FromDateTime));}
  else {$FromDateTime = date('Y-m-d H:i:s', 0);} //min

if ($ToDateTime != '')   
  {$ToDateTime   = date('Y-m-d H:i:s', strtotime($ToDateTime));}
  else {$ToDateTime   = date('Y-m-d H:i:s');} //now as max

$cond = "Timestamp >= '$FromDateTime' AND Timestamp <= '$ToDateTime' "; //DateTime must be in format here "2013-4-1" 
if (($FromDateTime=='') and ($ToDateTime=='')) {$cond='true';}


//show comments

$result = mysqli_query($mysqli, "SELECT * FROM Sensors_Comments WHERE ($cond) ORDER BY Timestamp ") or die("MySQL Error: ".mysqli_error($mysqli));

$CommentsNum = mysqli_num_rows  ($result );
if ($CommentsNum >0) 
  {  //<font color="red">This is some text!</font> 
  echo "<font color=$column11color>Comments: <br> \n";
  while ($row = mysqli_fetch_array($result)) 
    {
	//convert to unix format and decode to proper format
	$ts = strtotime($row['Timestamp']);
	$ts = date('m/d/Y H:i', $ts);
    //echo  $ts.": ";
    //echo  $row['Comments']."<br> \n";
	echo $ts.": ".$row['Comments']." (SensorID: ".$row['SensorID'].") <br> \n";
    }
  echo "</font> <br> \n";
  }
	
	
	
	

// GRAPHS
$graph_width=550; $graph_height=270;

GetMySQLData_CreateShow_Graph(4, $column6color);
GetMySQLData_CreateShow_Graph(3, $column5color);
echo " <br /> \n";
GetMySQLData_CreateShow_Graph(1);
GetMySQLData_CreateShow_Graph(2, $column4color);
echo " <br /> \n";
GetMySQLData_CreateShow_Graph(5, $column7color);
GetMySQLData_CreateShow_Graph(6, $column8color);
echo " <br /> \n";
GetMySQLData_CreateShow_Graph(7, $column9color);
GetMySQLData_CreateShow_Graph(8, $column10color);
echo " <br /> \n";



GetMySQLData_CreateShow_Graph(14, $column6color);
GetMySQLData_CreateShow_Graph(13, $column5color);
echo " <br /> \n";


GetMySQLData_CreateShow_Graph(11);
GetMySQLData_CreateShow_Graph(12, $column4color);
echo " <br /> \n";              

GetMySQLData_CreateShow_Graph(15, $column7color);
GetMySQLData_CreateShow_Graph(16, $column8color);
echo " <br /> \n";
GetMySQLData_CreateShow_Graph(17, $column9color);
GetMySQLData_CreateShow_Graph(18, $column10color);
echo " <br /> \n";


/////////////////////////////////////////////////////////////////


//if (strcasecmp($ShowDataTable, 'Yes') != 0) {$ShowDataTable='No';}
//echo "<a href=$page??FromDateTime=$FromDateTime&ToDateTime=$ToDateTime&ShowDataTable=$ShowDataTable&submit=Refresh+Graph> Table <a/> <br/>";

//if ($ShowDataTable=='Yes')
//  {echo "<a href=$page?ShowDataTable=No > Hide Table <a/> <br/>";}
//  else {echo "<a href=$page?ShowDataTable=Yes > Show Table <a/> <br/>";}



if (strcasecmp($ShowDataTable, 'Yes') == 0) 
  { //show table 
  //get number of records
  $result = mysqli_query($mysqli, "SELECT count(*) FROM $tablename") or die("MySQL Error: ".mysqli_error($mysqli)); 
  $row = mysqli_fetch_row($result); //enumerated array
  $reccount=$row[0];
  echo "Total Records Count: " .$reccount. ", ";
  //--
  $result = mysqli_query($mysqli, "SELECT count(*) FROM $tablename WHERE ($cond)") or die("MySQL Error: ".mysqli_error($mysqli)); 
  $row = mysqli_fetch_row($result); //enumerated array
  $reccount=$row[0];
  echo "Show Records Count: " .$reccount. "<br> \n";

  // Table
  $sqlstr ="SELECT * FROM $tablename WHERE ($cond) ORDER BY Timestamp";
  //echo '<br>'.$sqlstr;
  $result = mysqli_query($mysqli,$sqlstr) or die("MySQL Error: ".mysqli_error($mysqli)); 
  //get MySQL table header
  $columns = mysqli_query($mysqli,"SHOW COLUMNS FROM $tablename") or die("MySQL Error: ".mysqli_error($mysqli));
  //prepare HTML-table header
  echo "<table border='1'> \n";
  echo "</tr> \n";
  while ($row = mysqli_fetch_array($columns)) 
    {
    $rowheader = $row['0'];
    echo "<th BGCOLOR='#e0e0e0'> <FONT COLOR='#0000000'>".$rowheader."</th> \n";  
    }
  echo "</tr> \n";
  //fetch the data from the database
  $rownum ;
  $rowbgcolor;
  $rownum=0;
  while ($row = mysqli_fetch_array($result)) 
    {
    $rownum += 1; 
    //even or odd
    if ($rownum & 1) {$rowbgcolor = $evenrow_bg_color;} else  { $rowbgcolor = $oddrow_bg_color; }  
    echo  "<tr> \n";
    echo  "<td align='center' BGCOLOR=$rowbgcolor> <FONT COLOR=$column1color>".$row['Timestamp']."</FONT> </td> \n";
    echo  "<td align='center' BGCOLOR=$rowbgcolor> <FONT COLOR=$column2color>".$row['SensorID']."</FONT> </td> \n";
    echo  "<td align='center' BGCOLOR=$rowbgcolor> <FONT COLOR=$column3color>".$row['Value_AVE']."</FONT> </td> \n";
    echo  "<td align='center' BGCOLOR=$rowbgcolor> <FONT COLOR=$column4color>".$row['Value_Min']."</FONT> </td> \n";
    echo  "<td align='center' BGCOLOR=$rowbgcolor> <FONT COLOR=$column5color>".$row['Value_Max']."</FONT> </td> \n";
	echo  "<td align='center' BGCOLOR=$rowbgcolor> <FONT COLOR=$column5color>".$row['Value_STD']."</FONT> </td> \n";
    echo "</tr> \n";
    }
  //closing HTML-table  
  echo "</table> \n";
  }//end of show table

//close the connection
mysqli_close($mysqli);

?> 

</body> 
</html> 
