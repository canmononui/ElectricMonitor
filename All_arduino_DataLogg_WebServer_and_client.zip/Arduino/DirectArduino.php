<?php 
include "Include_file.php";   //see some constants and functions in here 
echo file_get_contents('http://'.$Arduino_IP); 
?> 
