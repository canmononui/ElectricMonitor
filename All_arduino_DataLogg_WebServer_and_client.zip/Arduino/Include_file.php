<?php
//jpGrapg
require_once ('/volume1/<your path>/jpgraph/jpgraph.php');
//not all may be used...
require_once ('/volume1/<your path>/jpgraph/jpgraph_line.php');
require_once ('/volume1/<your path>/jpgraph/jpgraph_bar.php');
require_once ('/volume1/<your path>/jpgraph/jpgraph_date.php');
// --------------------

$Arduino_IP = "192.168.0.200";

$username = "dbUserName";
$password = "dbPassword";
$hostname = "localhost";
$dbname = "Arduino";
//$tablename = "Sensors_WebLog";
$tablename = "Sensors_Data";  
$DescTableName = "Sensors_Desc";

$column1color = '#000000'; //timestamp
$column2color = '#000000'; //Meas_num
$column3color = '#0000ff'; //DHT11#1_H   
$column4color = '#ff0000'; //DHT11#1_T    //'#008000'; greenish
$column5color = '#ff0000'; //BMP085#1_T
$column6color = '#008050'; //BMP085#1_P   '#0060e0'
$column7color = '#0000ff'; //DHT22#1_H
$column8color = '#ff0000'; //DHT22#1_T
$column9color = '#0000ff'; //DHT22#2_H
$column10color = '#ff0000'; //DHT22#2_T
$column11color = '#660066'; //Comments

$evenrow_bg_color = '#FFFF99'; //'#FFCCFF';  
$oddrow_bg_color  = '#99FFCC'; //'#CCFFFF';  


//$prev = 1330518155 - (1330518155 % 1800);
//$next = $prev + 1800;


function CeilAccuracy ($value, $accuracy)
{
if ($accuracy == 0) {return $value;}
   else {return ceil($value/$accuracy) * $accuracy;}
}

function FloorAccuracy ($value, $accuracy)
{
if ($accuracy == 0) {return $value;}
   else {return floor($value/$accuracy) * $accuracy;}
}

function RoundAccuracy ($value, $accuracy)
{
if ($accuracy == 0) {return $value;}
   else {return round($value/$accuracy, 0) * $accuracy;}
}


function getAxisDivisions($minDataValue, $maxDataValue,
                          $PreferableDivNum, 
                          $PreferableDivMantissa = array (5, 2.5, 1) ) // only first value is using now  (5, 2.5, 1)
{
if ($minDataValue == $maxDataValue)
  {
  return array($minDataValue);
  }

$DivSize = ($maxDataValue - $minDataValue) / $PreferableDivNum; //not rounded
$SDivSize = sprintf("%E", $DivSize);
$Arr = explode("E", $SDivSize);
$Mantissa = floatval($Arr[0]);
$Power10 =$Arr[1]; 
//
//scan over all DivMantissas to find out best match (# of divisions is most close to $PreferableDivNum)  ----- not done yet, takes only last value from $PreferableDivMantissa, no search for the best
$DivCounter = array();
foreach ($PreferableDivMantissa as $DivM)
  {
  $MantissaDiv = RoundAccuracy($Mantissa, $DivM); 
  if ($MantissaDiv == 0) {$MantissaDiv = $DivM;} //can not be zero!
  $DivSize = $MantissaDiv * pow(10, $Power10);
  $HowManyDiv = ($maxDataValue - $minDataValue) / $DivSize;
  array_push ($DivCounter, $HowManyDiv);  
  }




//some validations
//if (($DivMantissa >=10) or ($DivMantissa <1)) {echo "Wrong Mantissa $DivMantissa (must be 1..9.999) <br>"; return FALSE;}  
if ($minDataValue > $maxDataValue) {echo "MinValue $minDataValue is more than Max Value $maxDataValue <br>"; return FALSE;}
if ($DivSize <= 0) {echo "Wrong DivSize $DivSize (must be>0) <br>"; return FALSE;}
//now creating array
$curvalue = CeilAccuracy($minDataValue, $DivSize);
$Epsilon = $DivSize * 0.01; //to avoid strict comparasion in the while-loop, accuracy - 1%
$Result = array();
while (($curvalue < $maxDataValue) OR  (abs($curvalue - $maxDataValue) < $Epsilon))  //($curvalue <= $maxDataValue) with epsilon   
  {
  array_push ($Result, $curvalue);
  $curvalue = $curvalue + $DivSize;
  }
return $Result;  
}


function rgb2html($r, $g=-1, $b=-1)
//rgb2html converts its arguments (r, g, b) to hexadecimal html-color string #RRGGBB Arguments are converted to integers 
//and trimmed to 0..255 range. It is possible to call it with array argument rgb2html($array_of_three_ints) 
//or specifying each component value separetly rgb2html($r, $g, $b).
{
if (is_array($r) && sizeof($r) == 3) list($r, $g, $b) = $r;    
$r = intval($r); 
$g = intval($g);    
$b = intval($b);    
$r = dechex($r<0?0:($r>255?255:$r));    
$g = dechex($g<0?0:($g>255?255:$g));    
$b = dechex($b<0?0:($b>255?255:$b));    
$color = (strlen($r) < 2?'0':'').$r;    
$color .= (strlen($g) < 2?'0':'').$g;    
$color .= (strlen($b) < 2?'0':'').$b;    
return '#'.$color;}

function html2rgb($color)
//html2rgb recognizes HTML or CSS colors in format #(hex_red)(hex_green)(hex_blue), where hex_red, hex_green and hex_blue 
//are 1 or 2-digit hex-representations of red, green or blue color components. # character in the beginning can be omitted. 
//Function returns array of three integers in range (0..255) or false when it fails to recognize color format.
{
if ($color[0] == '#') $color = substr($color, 1);
if (strlen($color) == 6) 
  list($r, $g, $b) = array($color[0].$color[1],
                           $color[2].$color[3],
						   $color[4].$color[5]);    
	elseif (strlen($color) == 3)        
	  list($r, $g, $b) = array($color[0].$color[0], 
	                           $color[1].$color[1], 
							   $color[2].$color[2]);    
	else return false;    
$r = hexdec($r); 
$g = hexdec($g); 
$b = hexdec($b);    
return array($r, $g, $b);
}

//jpGraph
function CreateGraph1($valuesArray, $keysArray, $GraphFilename, $GraphTitle, $img_width=800, $img_height=500, $DatalineColor='#FF4080')
{
$time_start = microtime(true);

//convert from string to numbers
for($i=0; $i<count($keysArray); $i++) { $keysArray[$i]=strtotime($keysArray[$i]); }

// Create the graph. These two calls are always required
$graph = new Graph($img_width, $img_height);
// Specify what scale we want to use,
//$graph->SetScale('textlin');
//$graph->SetScale('datlin');
$graph->SetScale('datlin', min($valuesArray),max($valuesArray), min($keysArray), max($keysArray) );
$graph->SetTickDensity(TICKD_DENSE, TICKD_DENSE);

//set border
$graph->SetFrame(true,'#000000', 1);
//borders
$margin_left = 50;
$margin_right = 10;
$margin_bottom = 105;
$margin_top = 30;
$graph->SetMargin($margin_left, $margin_right, $margin_top, $margin_bottom);

// Setup a title for the graph
$graph->title->Set($GraphTitle);
$graph->title->SetColor($DatalineColor);
$graph->title->SetPos(0,0,'left','bottom');

// Setup titles and X-axis labels
//$graph->xaxis->title->Set('Time');
//$graph->xaxis->SetTickLabels($keysArray); //if uncomment - first x-label is broken
$graph->xaxis->SetLabelAngle(90);
$graph->xaxis->SetLabelMargin(1); //space between 
//$graph->xaxis->SetPos('min');
//$graph ->xaxis->scale-> SetDateFormat( 'H:i'); 


// Setup Y-axis title
//$graph->yaxis->title->Set('Parameter');
$graph->yscale->SetAutoTicks(); 

// Create the linear plot
$lineplot=new LinePlot($valuesArray, $keysArray);
// Add the plot to the graph
$graph->Add($lineplot);
$lineplot->SetColor($DatalineColor);
$lineplot->SetWeight(1);

//fill color
$lineplot->SetFillColor("$DatalineColor@0.8"); //transparency, slower
 //marks - only for lines
$lineplot->mark->SetType(MARK_SQUARE);
$lineplot->mark->SetColor($DatalineColor);
$lineplot->mark->SetFillColor($DatalineColor);
$lineplot->mark->SetSize(2);

$graph->yscale->SetGrace(0,0);
 
 
 
//$lineplot->SetFastStroke(true); //to speedup, no marks, no fill
//$graph->img->SetAntiAliasing(false); //to speedup
 
// Display the graph (with papameter - to file)
$graph->Stroke($GraphFilename);

//timing
$time_end = microtime(true);
$time = round($time_end - $time_start, 2);
echo $time."\n";
}

//my func
function CreateGraph($valuesArray, $keysArray, $GraphFilename, $GraphTitle, $img_width=800, $img_height=500, $DatalineColor='#FF4080')
{
$time_start = microtime(true);

/*
$finfo = mysqli_fetch_fields($MySQLResult);
foreach ($finfo as $val) 
  {
  printf("Name:     %s <br /> \n", $val->name);
  printf("Table:    %s <br /> \n", $val->table);
  printf("max. Len: %d <br /> \n", $val->max_length);
  printf("Flags:    %d <br /> \n", $val->flags);
  printf("Type:     %d <br /> <br /> \n", $val->type);
  }
*/


$margin_left = 50;
$margin_right = 10;
$margin_bottom = 105;
$margin_top = 30;
$hor_lines=10;
$vert_lines=20;
// 
# ---- Find the size of graph by substracting the size of borders
$graph_width=$img_width - $margin_left-$margin_right;
$graph_height=$img_height - $margin_top-$margin_bottom; 
//$img=imagecreate($img_width,$img_height); //some glitches with border, replaced with "imagecreatetruecolor(...)"
$img=imagecreatetruecolor($img_width,$img_height); 

# -------  Define Colors ----------------
//$dataline_color=imagecolorallocate($img,255,64,128);
//$datamark_color=imagecolorallocate($img,255,64,128);
$rgb=html2rgb($DatalineColor);
$dataline_color=imagecolorallocate($img,$rgb[0],$rgb[1],$rgb[2]);
$datamark_color=imagecolorallocate($img,$rgb[0],$rgb[1],$rgb[2]);
$datamark_size=1;
$datafill_color = imagecolorallocatealpha ($img,$rgb[0],$rgb[1],$rgb[2], 110); //transparent

//$datalbl_color=imagecolorallocate($img,200,0,0); //not used now
$background_color=imagecolorallocate($img,240,240,255);
$border_color=imagecolorallocate($img,200,200,200);
$hline_color=imagecolorallocate($img,170,170,170);
$vline_color=imagecolorallocate($img,170,170,170);
$title_color=imagecolorallocate($img,0,0,255);
$vline_label_color=imagecolorallocate($img,0,64,128);
$hline_label_color=imagecolorallocate($img,0,64,128);
//
# ------ Create the border around the graph ------
imagefilledrectangle($img,1,1,$img_width-2,$img_height-2,$border_color);
imagefilledrectangle($img,$margin_left,$margin_top,$img_width-1-$margin_right,$img_height-1-$margin_bottom,$background_color); //non simmetrical
//
$total_points=count($valuesArray);
if (($total_points) == 0) 
  {  //no data
  //make title
  $title_arr = explode("\n", $GraphTitle);
  if (count($title_arr)>2) {$title_arr[1] = trim($title_arr[1]).'...';}
  imagestring($img,3,5,0,trim($title_arr[0]),$dataline_color /*$title_color*/);
  imagestring($img,3,5,10,trim($title_arr[1]),$dataline_color /*$title_color*/);
  //
  imagestring($img, 20, $img_width/2-20,$img_height/2,"NO DATA",$dataline_color /*$title_color*/);
  //save and destroy image	
  imagepng($img, $GraphFilename);
  imagedestroy($img);
  return;
  }
  
//convert keys to Unix Timestamp (needs to calculate scale)
for($i=0;$i< $total_points; $i++) { $keysArray[$i]=strtotime($keysArray[$i]); }
# ------- MinMax is required to adjust the scale	-------
$max_value=max($valuesArray);
$min_value=min($valuesArray);
if ($max_value != $min_value) 
  {$y_ratio= $graph_height/($max_value-$min_value);}
  else {$y_ratio= 0;}
//
$max_key=max($keysArray);
$min_key=min($keysArray);
if ($max_key!=$min_key) 
  {$x_ratio= $graph_width/($max_key-$min_key);}
  else {$x_ratio = 0;}

   
# -------- draw horizontal lines  --------
$arr = getAxisDivisions($min_value, $max_value, 10, array (2.5) );
for($i=0;$i<count($arr);$i++)
    {
	if ($y_ratio != 0) 
	  {$y=$margin_top +$graph_height-         (($arr[$i] -$min_value) * $y_ratio);}
	  else {$y=$margin_top + $graph_height/2;}
	
	if (round($arr[$i],5) == round($arr[$i]))	//integer? (5 digits accuracy)
	  {//integer, solid line
	  imageline($img,$margin_left,$y,$img_width-$margin_right,$y,$hline_color); 
	  }
	  else 
       {//not integer, dashed line
	   $style = array($hline_color, $background_color, $background_color, $background_color); //style for dashed line
       imagesetstyle($img, $style);
	   imageline ($img,$margin_left,$y,$img_width-$margin_right,$y, IMG_COLOR_STYLED); //dashed line in defined style
       }
	if ($y_ratio != 0)
	  {	imagestring($img,2,7,$y-7,$arr[$i],$hline_label_color);}
	  else 
	  {	imagestring($img,2,7,$y-7,$min_value,$hline_label_color);}
	}

	
# -------- draw vertical lines lines  --------
$arr = getAxisDivisions($min_key/86400, $max_key/86400, 40, array (4.1666667) ); // 86400 - seconds in a day,   4.166667 (1/24) - every hour or 0.1 hour (6 min) or 10 hours or 100 hours
for($i=0;$i<count($arr);$i++)     {$arr[$i] = $arr[$i] * 86400;} //restore to timedate

for($i=0;$i<count($arr);$i++)
    {
	if ($x_ratio != 0) 
	  {$x=$margin_left + ($arr[$i]-$min_key) * $x_ratio;}
	  else {$x=$margin_left + $graph_width/2;}
	  
	if (strcmp (date('H:i', $arr[$i]), '00:00') == 0)  //midnight
	  {//round hour, solid line
	  imageline($img, $x, $margin_top, $x, $img_height-$margin_bottom, $vline_color);	
	  }
	  else 
	    {
		if (strcmp (date('i', $arr[$i]), '00') == 0)  //round hour?
		  {$style = array($vline_color, $vline_color, $vline_color, $background_color,$background_color,$background_color);} //style for round hour (but not midnight)
		    else  
			{$style = array($vline_color, $background_color, $background_color, $background_color,$background_color,$background_color);} //style for not round hour
		//dashed line
        imagesetstyle($img, $style);
		imageline($img, $x, $margin_top, $x, $img_height-$margin_bottom, IMG_COLOR_STYLED);	
		}
	
	imagestringup($img,2,$x-7,$img_height-5, date('m/d/Y H:i', $arr[$i]) ,$vline_label_color);  //format hor. labels here
	}

if (count($arr) >2)
  {$HorDiv = round(($arr[1] - $arr[0]) / 3600, 3);}
  else {$HorDiv = 0;}
imagestring($img,3,300,0,"Hor.Div: $HorDiv Hour(s)",$dataline_color /*$title_color*/);
	
	
//echo date('m/d/Y H:i:s', RoundAccuracy ($keysArray[0], 3600*3));	
	
	
# ----------- Draw main line here ------  
$datafill_array = array();//create datafill array
for($i=0; $i<$total_points; $i++)
	{ 
	$key = $keysArray[$i];  
	$value =$valuesArray[$i];
	
	if ($x_ratio != 0) 
	  {$x= $margin_left + ($key-$min_key) * $x_ratio;}    //calculated using real scale ($key), not indexes, use $min_key and $x_ratio   
	   else {$x = $margin_left + $graph_width/2;}
	   
	if ($y_ratio != 0) 
	  {$y=$margin_top +$graph_height-         (($value -$min_value) * $y_ratio);}
	  else {$y=$margin_top + $graph_height/2;}
	
	//imagestring($img,2,$x-7,$y-13,$value,$datalbl_color);  //labels

	//point datamark
	imagefilledrectangle($img, $x-$datamark_size,  $y-$datamark_size,  $x+$datamark_size,   $y+$datamark_size, $datamark_color);	
	
	//line (with antialiasing)
    imageantialias($img, true); //antialiasing on 
	if ($i != 0) {imageline($img, $x, $y, $x_prev, $y_prev, $dataline_color);}
    imageantialias($img, false); //antialiasing off

	//datafill array fillout, draw it later, after cycle
	array_push ($datafill_array, $x, $y);
	
	//update previous point coordinates
	$x_prev=$x;
    $y_prev=$y;  
	}
	
//datafill drawing, fill from the bottom to the line
array_push ($datafill_array, $datafill_array[count($datafill_array)-2], $margin_top+$graph_height); //last $x on the bottom line
array_push ($datafill_array, $datafill_array[0],                        $margin_top+$graph_height); //first $x on the bottom line
imagefilledpolygon ($img , $datafill_array , count($datafill_array)/2, $datafill_color);
	
//make title
$title_arr = explode("\n", $GraphTitle);
if (count($title_arr)>2) {$title_arr[1] = trim($title_arr[1]).'...';}
imagestring($img,3,5,0,trim($title_arr[0]),$dataline_color /*$title_color*/);
imagestring($img,3,5,10,trim($title_arr[1]),$dataline_color /*$title_color*/);
//imagettftext($img, 10, 0, 5, 12, $dataline_color, 'arial.ttf', $GraphTitle); //ttf-file must exist

//MinMax
//imagestring($img,3,430,0,"Min: $min_value, Max: $max_value",$dataline_color /*$title_color*/);
imagestring($img,3,460,0,"Max: $max_value",$dataline_color /*$title_color*/);
imagestring($img,3,460,10,"Min: $min_value",$dataline_color /*$title_color*/);

//save and destroy image	
imagepng($img, $GraphFilename);
imagedestroy($img);

$time_end = microtime(true);
$time = round($time_end - $time_start, 2);
//echo $time."\n";
} // end of Create3WeeksGraph(...)
/////////////////////





/*
function CreateGraph($MySQLResult, $GraphFilename, $GraphTitle, $img_width=800, $img_height=500)
{
//convert SQLResult to $dataArray
unset($dataArray);
while ($row = mysqli_fetch_array($MySQLResult))  {$dataArray[$row[0]] = $row[1];}
$margin_left = 60;
$margin_right = 30;
$margin_bottom = 110;
$margin_top = 20;
$hor_lines=10;
$vert_lines=20;
// 
# ---- Find the size of graph by substracting the size of borders
$graph_width=$img_width - $margin_left-$margin_right;
$graph_height=$img_height - $margin_top-$margin_bottom; 
//$img=imagecreate($img_width,$img_height); //some glitches with border, replaced with "imagecreatetruecolor(...)"
$img=imagecreatetruecolor($img_width,$img_height); 
# -------  Define Colors ----------------
$dataline_color=imagecolorallocate($img,255,64,128);
$datamark_color=imagecolorallocate($img,255,64,128);
//$datalbl_color=imagecolorallocate($img,200,0,0); //not used now
$background_color=imagecolorallocate($img,240,240,255);
$border_color=imagecolorallocate($img,200,200,200);
$hline_color=imagecolorallocate($img,170,170,170);
$vline_color=imagecolorallocate($img,170,170,170);
$title_color=imagecolorallocate($img,0,0,255);
$vline_label_color=imagecolorallocate($img,0,64,128);
$hline_label_color=imagecolorallocate($img,0,64,128);
//
$total_points=count($dataArray);
$vlines_gap = $graph_width/($total_points-1); //not right for x scale!
//split the dataarray to the keys and values arrays
$valuesArray = array_values($dataArray);
$keysArray = array_keys($dataArray);
//convert keys to Unix Timestamp (needs to calculate scale)
for($i=0;$i< $total_points; $i++) { $keysArray[$i]=strtotime($keysArray[$i]); }
# ------ Create the border around the graph ------
imagefilledrectangle($img,1,1,$img_width-2,$img_height-2,$border_color);
imagefilledrectangle($img,$margin_left,$margin_top,$img_width-1-$margin_right,$img_height-1-$margin_bottom,$background_color); //non simmetrical
# ------- MinMax is required to adjust the scale	-------
$max_value=max($valuesArray);
$min_value=min($valuesArray);
$y_ratio= $graph_height/($max_value-$min_value);
//
$max_key=max($keysArray);
$min_key=min($keysArray);
$x_ratio= $graph_width/($max_key-$min_key);
# -------- draw horizontal lines  --------
$hlines_gap=$graph_height/$hor_lines;
for($i=0;$i<=$hor_lines;$i++)
    {
	$y=$img_height - $margin_bottom - $hlines_gap * $i ;
	imageline($img,$margin_left,$y,$img_width-$margin_right,$y,$hline_color);
	$v=        (($hlines_gap * $i / $y_ratio) + $min_value);
	imagestring($img,2,7,$y-7,$v,$hline_label_color);
	}
# -------- draw vertical lines lines  --------
$vlines_gap=$graph_width/$vert_lines;
for($i=0;$i<=$vert_lines;$i++)
    {
	$x=$margin_left + $vlines_gap * $i ;
	imageline($img, $x, $margin_top, $x, $img_height-$margin_bottom, $vline_color);
	$v=(($vlines_gap * $i / $x_ratio) + $min_key);
	imagestringup($img,2,$x-7,$img_height-5, date('m/d/Y H:i', $v) ,$vline_label_color);  //format hor. labels here
	}
# ----------- Draw main graph here ------
for($i=0;$i< $total_points; $i++)
	{ 
	$key = $keysArray[$i];  
	$value =$valuesArray[$i];
	$x= $margin_left + ($key-$min_key) * $x_ratio;    //calculated using real scale ($key), not indexes, use $min_key and $x_ratio   
	$y=$margin_top +$graph_height-         (($value -$min_value) * $y_ratio) ;
	//imagestring($img,2,$x-7,$y-13,$value,$datalbl_color);  //labels
	//point
	imagefilledrectangle($img, $x-1,  $y-1,  $x+1,   $y+1, $datamark_color);
	//line
	if ($i != 0) {imageline($img, $x, $y, $x_prev, $y_prev, $dataline_color);}
	//update previous point coordinates
	$x_prev=$x;
    $y_prev=$y;  
	}
//make title
imagestring($img,3,5,0,$GraphTitle,$title_color);
//save and destroy image	
imagepng($img, $GraphFilename);
imagedestroy($img);
} // end of Create3WeeksGraph(...)
*/



/////////////////////




?>

